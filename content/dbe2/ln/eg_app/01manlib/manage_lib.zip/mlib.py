import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

import MySQLdb
from MySQLdb.cursors import Cursor
from MySQLdb._exceptions import MySQLError

def connect_db():
    conn = MySQLdb.connect(
          host="localhost",
          user="root",
          passwd="",
          db="dbe2",
          charset='utf8',
          autocommit=True,
    )
    return conn.cursor(Cursor)

# @app.route('/my_static/<filename>')
# def func_static(filename):
#     return static_file(filename, root='./my_static_file')

@app.route('/')
def func_root():
    return redirect('/static/html/top.html')

@app.route('/search_user_top')
def func_search_user():
    return render_template("search_user_top.html")

@app.route('/search_user_uid', methods=['GET', 'POST'])
def func_search_user_post():
    if request.method == 'POST':
        req = request.form
    else:
        req = request.args
    uid = req.get('uid')
    with connect_db() as cursor:
        sql = 'SELECT 氏名, 電話番号 FROM 利用者 WHERE 利用者ID = %s'
        cursor.execute(sql, [uid])
        info = None
        for c in cursor:
            info = c
        if not info:
            msg = f'指定された利用者ID ({uid}) は存在しません'
            return render_template('error.html', msg=msg)
    return render_template("search_user_result.html", uid=uid, info=info)

@app.route('/search_user_uname', methods=['POST'])
def func_search_user_uname():
    return render_template('not_implemented.html')
    
@app.route('/search_user_uname_like', methods=['POST'])
def func_search_user_uname_like():
    req = request.form
    uname_like = req.get('uname_like')
    with connect_db() as cursor:
        sql = 'SELECT 利用者ID, 氏名 FROM 利用者 WHERE 氏名 LIKE %s'
        cursor.execute(sql, [uname_like + '%%'])
        info = list(cursor)
    if not info:
        msg = f'指定された氏名(前方一致)「{uname_like}」に合致する' + \
            'データがみつかりませんでした．'
        return render_template('error.html', msg=msg)
    return render_template("search_user_result_list.html", info=info)

@app.route('/search_book_top')
def func_search_book_top():
    return render_template("not_implemented.html")

@app.route('/lend_top')
def func_lend_top():
    return render_template('lend_top.html')


def sub_lend_check(uid, bid):
    with connect_db() as cursor:
        sqlU = '''SELECT 利用者ID, 氏名, 電話番号 
        FROM 利用者 WHERE 利用者ID = %s'''
        sqlB = '''SELECT 書籍ID, 著者, タイトル FROM 書籍 
        WHERE 書籍ID = %s'''
        sqlL = '''SELECT COUNT(*) FROM 貸出
        WHERE 利用者 = %s AND 返却日 IS NULL'''
        cursor.execute(sqlU, [uid])
        infoU = None
        for row in cursor:
            infoU = row
        if not infoU:
            msg = f'指定された利用者{uid}は存在しません．'
            return (None, None, msg)
        cursor.execute(sqlB, [bid])
        infoB = None
        for row in cursor:
            infoB = row
        if not infoB:
            msg = f'指定された書籍{bid}は存在しません．'
            return (None, None, msg)
        cursor.execute(sqlL, [uid])
        for row in cursor:
            num = row[0]
        if num > 0:
            msg = f'利用者{uid}には，返却していない書籍が{num}冊あります．'
            return (None, None, msg)
        return (infoU, infoB, None)

@app.route('/lend', methods=['POST'])
def func_lend_check():
    req = request.form
    uid = req.get('uid')
    bid = req.get('bid')
    lend_date = req.get('lend_date')
    due_date = req.get('due_date')
    execute = req.get('execute')

    (infoU, infoB, msg) = sub_lend_check(uid, bid)
    if msg:
        return render_template('error.html', msg=msg)
    if execute == 'YES':
        sql = '''INSERT 貸出(利用者, 書籍, 貸出日, 返却予定日) VALUES
        (%s, %s, %s, %s)'''
        with connect_db() as cursor:
            cursor.execute(sql, [uid, bid, lend_date, due_date])
        return render_template('lend_done.html')
    else:
        return render_template('lend_after_check.html',
                               infoU=infoU, infoB=infoB,
                               lend_date=lend_date, due_date=due_date)

@app.route('/return_top')
def func_return_top():
    return render_template("not_implemented.html")

app.run(host='localhost', port=8088, debug=True)
