import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

@app.route('/')
def func_root():
    return render_template('templ2_start.html')

@app.route('/calc')
def func_calc():
    return render_template('templ2_start.html')

@app.route('/act2', methods=['POST'])
def func_act2():

    req = request.form

    try:
        fld = 1
        v_num1 = int(req.get('num1'))
        fld = 2
        v_num2 = int(req.get('num2'))
        fld = 3
        v_num3 = int(req.get('num3'))
    except ValueError as e:
        return render_template('form2_error.html',
                               msg=f'数{fld}が数値ではありません．')
        
    v_checked = req.getlist('type')
    # print('\n***** v_checked = ', v_checked, '******\n')

    v_cnt = len(v_checked)
    return render_template('templ2_result.html', t_checked=v_checked,
                           t_num1=v_num1, t_num2=v_num2, t_num3=v_num3,
                           t_cnt=v_cnt)

@app.route('/act3', methods=['POST'])
def func_act3():

    req = request.form
    row = int(req.get('row'))
    col = int(req.get('col'))
    with_header = req.get('with_header')

    # ここで，リストのリスト multiples を組み立てている．
    multiples = []

    if with_header == None:
        # 見出しをつけない場合

        for r in range(1, row + 1):
            m_row = []
            for c in range(1, col + 1):
                m_row.append(r * c)
            multiples.append(m_row)

        # 実際にどのようなリストが組み立てられたのか，下の print 文を
        # アンコメントして確認してみること．コマンドプロンプトに表示される．
        print(f'\n****** multiples = {multiples} ******\n')
        return render_template('templ2_multiples_result.html', 
                               multiples=multiples)

    else:
        # 見出しをつける場合

        # 先頭行は，header というリストに格納する
        header = []
        for c in range(1, col + 1):
            header.append(c)

        # 2行目以降
        #   リスト multiples の各要素は，
        #   最左列(見出し) とそれ以外(データのリスト) のペアにする．
        for r in range(1, row + 1):
            m_row = []
            for c in range(1, col + 1):
                m_row.append(r * c)
            # 最左列 r とデータ m_row のペアを multiples に追加する
            multiples.append((r, m_row))   

        return render_template('templ2_multiples_result_wh.html', 
                               header=header, multiples=multiples)

students= [['2824991', '赤間一郎', '090-1111-1111'],
           ['2824995', '岩瀬春子', '090-1111-1112'],
           ['2824997', '内田二郎', '090-1111-1113'],
           ['2824984', '遠藤夏子', '090-1111-1114'],
           ['2824982', '大岩三郎', '090-1111-1115'],
           ['2824989', '加藤秋子', '090-1111-1116']]

@app.route('/exc_course')
def func_course():
    return render_template('course_start.html')

app.run(host='localhost', port=8088, debug=True)
