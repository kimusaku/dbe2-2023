import bottle
from bottle import route, run, template, request, static_file, redirect

import MySQLdb
from MySQLdb.cursors import Cursor
from MySQLdb._exceptions import MySQLError

def connect_db():
    conn = MySQLdb.connect(
          host="localhost",
          user="root",
          passwd="",
          db="dbe2",
          charset='utf8',
          autocommit=True,
    )
    return conn.cursor(Cursor)

@route('/')
def func_root():
    return template('top')

@route('/login', method='GET')
def func_login_get():
    return template('bad_login')

@route('/login', method='POST')
def func_login_post():
    req = request.params.decode()
    username = req.get('username')
    password = req.get('password')
    with connect_db() as cursor:
        sql = 'SELECT password from userA where username = %s'
        cursor.execute(sql, [username])
        res = None
        for c in cursor:
            res = c
        if not res:
            return template('error', msg='ユーザ名が間違っています')
        if res[0] != password:
            return template('error', msg='パスワードが間違っています')
    redirect(f'/user_top?username={username}')
                            
@route('/show_secret')
def func_show_secret():
    req = request.params.decode()
    username = req.get('username')
    with connect_db() as cursor:
        sql = 'SELECT secret from userA where username = %s'
        cursor.execute(sql, [username])
        res = None
        for c in cursor:
            res = c
    return template('bad_show_secret', username=username, secret=c[0])

@route('/user_top')
def func_user_top():
    req = request.params.decode()
    username = req.get('username')
    return template('bad_user_top', username=username)

@route('/logout')
def func_logout():
    redirect('/login')


bottle.debug(True)
run(port=8080, reloader=True)
