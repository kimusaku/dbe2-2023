import bottle
from bottle import route, run, template, request, static_file, redirect
from beaker.middleware import SessionMiddleware
import bcrypt

import MySQLdb
from MySQLdb.cursors import Cursor
from MySQLdb._exceptions import MySQLError

def connect_db():
    conn = MySQLdb.connect(
          host="localhost",
          user="root",
          passwd="",
          db="dbe2",
          charset='utf8',
          autocommit=True,
    )
    return conn.cursor(Cursor)

def set_username(name):
    sess = request.environ.get('beaker.session')
    sess['username'] = name
    sess.save()

def get_username():
    sess = request.environ.get('beaker.session')
    if not sess['username']:
        redirect(f'/login')
    return sess['username']

@route('/')
def func_root():
    return template('top')

@route('/login', method='GET')
def func_login_get():
    return template('login')

@route('/login', method='POST')
def func_login_post():
    req = request.params.decode()
    username = req.get('username')
    password = req.get('password')
    with connect_db() as cursor:
        sql = 'SELECT hashed from userB where username = %s'
        cursor.execute(sql, [username])
        res = None
        for c in cursor:
            res = c
    msg = 'ユーザ名またはパスワードが間違っています．'
    if not res:
        return template('error', msg=msg)
    if not bcrypt.checkpw(password.encode(), c[0].encode()):
        return template('error', msg=msg)
    set_username(username)
    redirect(f'/user_top')
                            
@route('/register', method='POST')
def func_register():
    req = request.params.decode()
    username = req.get('username')
    password1 = req.get('password1')
    password2 = req.get('password2')
    if password1 != password2:
        return template('error', msg='パスワードが一致しません．')
    if len(password1) <= 7:
        return template('error', msg='パスワードは8文字以上にしてください．')
    # 本当はここでさまざまなチェックを行うべきである
    hashed = bcrypt.hashpw(password1.encode(), bcrypt.gensalt()).decode()
    with connect_db() as cursor:
        sql = 'INSERT userB(username, hashed) VALUES (%s, %s)'
        cursor.execute(sql, [username, hashed])
    set_username(username)
    redirect(f'/user_top')

@route('/user_top')
def func_user_top():
    username = get_username()
    return template('user_top', username=username)

@route('/show_secret')
def func_show_secret():
    username = get_username()
    with connect_db() as cursor:
        sql = 'SELECT secret from userB where username = %s'
        cursor.execute(sql, [username])
        res = None
        for c in cursor:
            res = c
    return template('show_secret', username=username, secret=c[0])

@route('/set_secret', method='GET')
def set_secret_get():
    username = get_username()
    return template('set_secret', username=username)

@route('/set_secret', method='POST')
def set_secret_post():
    username = get_username()
    req = request.params.decode()
    secret = req.get('secret')
    with connect_db() as cursor:
        sql = 'UPDATE userB SET secret = %s WHERE username = %s'
        cursor.execute(sql, [secret, username])
    redirect('/user_top')

@route('/logout')
def func_logout():
    set_username(None)
    redirect('/login')

session_opts = {
    'session.type': 'file',
    'session.cookie_expires': 300,
    'session.data_dir': './data',
    'session.auto': True
}
app = SessionMiddleware(bottle.app(), session_opts)
        
bottle.debug(True)
run(app=app, port=8080, reloader=True)
