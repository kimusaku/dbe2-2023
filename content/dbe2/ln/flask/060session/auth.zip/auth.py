import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
from flask_login import LoginManager, UserMixin, login_user, current_user, login_required, logout_user
import scrypt
from flask_wtf.csrf import CSRFProtect
import os
from base64 import b64encode, b64decode

app = Flask(__name__)

import MySQLdb
from MySQLdb.cursors import Cursor
from MySQLdb._exceptions import MySQLError

def connect_db():
    conn = MySQLdb.connect(
          host='localhost',
          user='root',
          passwd='',
          db='dbe2',
          charset='utf8',
          autocommit=True,
    )
    return conn.cursor(Cursor)

login_manager = LoginManager()
login_manager.init_app(app)

app.secret_key = 'c419e9be86cf484f9967a3b3e2b89850'
CSRFProtect(app)

class User(UserMixin):
    def __init__(self, username, realname):
        self.username = username
        self.realname = realname
    def __repr__(self):
        return f'User({self.username})'
    def get_id(self):
        return self.username
        
@login_manager.user_loader
def load_user(username):
    with connect_db() as cursor:
        sql = 'SELECT realname FROM userInfo WHERE username = %s'
        cursor.execute(sql, [username])
        for c in cursor:
            return User(username, c[0])
        return None

@login_manager.unauthorized_handler
def unauthorized_handler():
    return render_template('login_required.html')

@app.route('/')
def func_root():
    return redirect('/static/html/top.html')

@app.route('/login', methods=['GET', 'POST'])
def func_login():
    if request.method == 'GET':
        return render_template('login.html')
    req = request.form
    username = req.get('username')
    password = req.get('password')
    with connect_db() as cursor:
        sql = 'SELECT hashed, salt, realname FROM userInfo WHERE username = %s'
        cursor.execute(sql, [username])
        hashed = None
        for c in cursor:
            (hashed, salt, realname) = c
        if hashed is not None:
            bin_salt = b64decode(salt)
            bin_hashed = b64decode(hashed)
            if scrypt.hash(password.encode(), bin_salt) == bin_hashed:
                login_user(User(username, realname))
                return redirect('/welcome')
        msg = f'ユーザ名またはパスワードが正しくありません'
        return render_template('error.html', msg=msg)

@app.route('/welcome')
@login_required
def func_welcome():
    return render_template('welcome.html')

@app.route('/secret')
@login_required
def func_secret():
    req = request.args
    username = current_user.username
    with connect_db() as cursor:
        sql = 'SELECT secret, realname FROM userInfo WHERE username = %s'
        cursor.execute(sql, [username])
        for c in cursor:
            info = c
    return render_template('secret.html', secret=info[0], realname=info[1])
    
@app.route('/logout')
def func_logout():
    logout_user()
    return redirect('/login')

app.run(host='localhost', port=8088, debug=True)
