import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

import MySQLdb
from MySQLdb.cursors import Cursor
from MySQLdb._exceptions import MySQLError

def connect_db():
    conn = MySQLdb.connect(
          host='localhost',
          user='root',
          passwd='',
          db='dbe2',
          charset='utf8',
          autocommit=True,
    )
    return conn.cursor(Cursor)

@app.route('/')
def func_root():
    return redirect('/static/html/top.html')

@app.route('/login', methods=['GET', 'POST'])
def func_login():
    if request.method == 'GET':
        return render_template('login_bad.html')
    req = request.form
    username = req.get('username')
    password = req.get('password')
    with connect_db() as cursor:
        sql = 'SELECT password, realname FROM userInfoBad WHERE username = %s'
        cursor.execute(sql, [username])
        info = None
        for c in cursor:
            info = c
        if not info:
            msg = f'指定されたユーザ名 {username} は存在しません'
            return render_template('error.html', msg=msg)
        if info[0] != password:
            msg = f'パスワード {password} が正しくありません'
            return render_template('error.html', msg=msg)
    return render_template('welcome_bad.html',
                           username=username, realname=info[1])

@app.route('/secret')
def func_secret():
    req = request.args
    username = req.get('username')
    with connect_db() as cursor:
        sql = 'SELECT secret, realname FROM userInfoBad WHERE username = %s'
        cursor.execute(sql, [username])
        for c in cursor:
            info = c
    return render_template('secret.html', secret=info[0], realname=info[1])
    
@app.route('/logout')
def func_logout():
    return redirect('/login')

app.run(host='localhost', port=8088, debug=True)
