import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

@app.route('/st/2b')
def func_st_2b():
    # template() 呼び出しに，変数=値 という形で追加すると，
    # テンプレートの中で，変数がその値に設定される．
    return render_template('stB.html', hoge='こんにちは')

@app.route('/st/2c')
def func_st_2c():
    # 複数個渡したいときにはカンマで区切って並べる．
    # ここで変数に代入して，変数を渡しても良い．
    # (ここの変数はテンプレートの中では参照できない．
    uchidajiro = '内田二郎'
    endo = '遠藤'
    natsuko = '夏子'
    endonatsuko = endo + natsuko
    return render_template('stC.html', name1='赤尾一郎', name2='岩瀬春子',
                    name3=uchidajiro, name4=endonatsuko)


@app.route('/st/2d')
def func_st_2d():
    # Python では，datetime.datetime.now() で現在時刻が取得できる．
    # 取得できるのは「datetimeオブジェクト」であるが，関数str() に
    # 渡すことで，文字列に変換できる．
    # そこで，以下のようにして，時刻を表示するページを作ることができる．
    import datetime
    now_o = datetime.datetime.now()
    s = str(now_o)
    return render_template('stD.html', nowtime=s)
    # 上の3行は，もちろん，次のようにまとめて書くこともできる:
    #     return render_template('stD.html',
    #                            nowtime=str(datetime.datetime.now()))

app.run(host='localhost', port=8088, debug=True)

