import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

@app.route('/st/1')
def func_st_1():
    # render_template(filename) を return の値として指定すると，
    # テンプレートファイル filename の内容がブラウザに送られる．
    # テンプレートファイルは，templates というサブディレクトリに置く．
    return render_template('stA.html')

app.run(host='localhost', port=8088, debug=True)

