import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

@app.route('/')
def func_root():
    return render_template('form1.html')

# <form>タグでは，method として POST と GET が指定できる．
# POST 指定されたデータを受け取るためには，@app.route の引数 methods
# に，['POST'] または ['GET', 'POST'] を指定する必要がある．
@app.route('/act1', methods=['POST'])
def func_act1():

    # ユーザがフォームから送ってきたデータを取得するには，
    # 最初に req = request.form を
    # 実行して，辞書 (のようなもの) req を得る．
    # req の中に，ユーザ入力した情報が格納されている．
    req = request.form

    # text1 という name を持つフィールドに入力された値は，
    # req.get('text1') で取り出すことができる．
    v_text1 = req.get('text1')
    v_cb1 = req.get('cb1')
    v_value1 = req.get('key1')
    return render_template('form1_result.html',
                           t_text1=v_text1, t_cb1=v_cb1, t_value1=v_value1);

@app.route('/calc')
def func_calc():
    return render_template('form2.html')

@app.route('/act2', methods=['POST'])
def func_act2():

    req = request.form

    # req['...'] で得られる値は文字列である．
    # 数として扱いたいのならば，int(...) 等を用いて，変換する必要がある．
    v_num1 = int(req.get('num1'))
    # もしくは，req.get(key, type=....) を使うこともできる:
    v_num2 = req.get('num2', type=int) # v_num2 = int(req.get('num2')) でも同じ．
    # 複数のチェックボックスに同じ名前を指定しているときには，
    # req.getlist() を呼ぶことで，チェックされた値のリストを得ることができる．
    checked = req.getlist('type')
    # print('\n***** checked = ', checked, '******\n')
    # ユーザが和だけをチェックしていれば，checked の値は ['sum']
    # ユーザが和と積をチェックしていれば，checked の値は ['sum', 'product']
    # どちらもチェックしていなければ，    checked の値は []

    if len(checked) == 0:
        return render_template('form2_error.html',
                               msg='計算が指定されていません．')
    elif len(checked) >= 2:
        return render_template('form2_error.html',
                               msg='複数の計算が指定されています．')
    elif checked[0] == 'sum':
        return render_template('form2_result.html',
                               t_num1=v_num1, t_num2=v_num2,
                               t_symb='+', t_val=v_num1 + v_num2)
    elif checked[0] == 'product':
        return render_template('form2_result.html',
                               t_num1=v_num1, t_num2=v_num2,
                               t_symb='*', t_val=v_num1 * v_num2)
    else:
        return render_template('form2_error.html', msg='不正なアクセスです．')

app.run(host='localhost', port=8088, debug=True)
